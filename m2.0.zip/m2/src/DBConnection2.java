import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection2 {
    private Connection con;
    private static final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
    private static final String DB_URL = "jdbc:derby:BcWellnessDB;create=true";

    public DBConnection2() throws SQLException {
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException ex) {
            System.err.println("Derby driver not found.");
            ex.printStackTrace();
        }

        con = DriverManager.getConnection(DB_URL);
        createFeedbackTable();
        createCounselorTable();
        createAppointmentTable(); // ✅ Now we include it!
    }

    private void createFeedbackTable() throws SQLException {
        String sql = "CREATE TABLE feedback (" +
                     "student_name VARCHAR(100), " +
                     "counselor_name VARCHAR(100), " +
                     "rating INT, " +
                     "comments VARCHAR(500))";

        try (Statement stmt = con.createStatement()) {
            stmt.executeUpdate(sql);
            System.out.println("Feedback table created.");
        } catch (SQLException e) {
            if (!e.getSQLState().equals("X0Y32")) throw e;
            System.out.println("Feedback table already exists.");
        }
    }

    private void createCounselorTable() throws SQLException {
        String sql = "CREATE TABLE CounselorManage (" +
                     "Name VARCHAR(100), " +
                     "specialization VARCHAR(100), " +
                     "availability VARCHAR(50))";

        try (Statement stmt = con.createStatement()) {
            stmt.executeUpdate(sql);
            System.out.println("CounselorManage table created.");
        } catch (SQLException e) {
            if (!e.getSQLState().equals("X0Y32")) throw e;
            System.out.println("CounselorManage table already exists.");
        }
    }

    private void createAppointmentTable() throws SQLException {
        String sql = "CREATE TABLE Appointments (" +
                     "\"Student Name\" VARCHAR(100), " +  // ✅ Use double quotes
                     "\"Counselor\" VARCHAR(100), " +
                     "\"Date\" VARCHAR(50), " +
                     "\"Time\" VARCHAR(50), " +
                     "\"Status\" VARCHAR(50))";

        try (Statement stmt = con.createStatement()) {
            stmt.executeUpdate(sql);
            System.out.println("Appointments table created.");
        } catch (SQLException e) {
            if (!e.getSQLState().equals("X0Y32")) throw e;
            System.out.println("Appointments table already exists.");
        }
    }

    public Connection getConnection() {
        return con;
    }

    public static void main(String[] args) {
        try {
            new DBConnection2();
        } catch (SQLException ex) {
            System.out.println("Database setup error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
    
