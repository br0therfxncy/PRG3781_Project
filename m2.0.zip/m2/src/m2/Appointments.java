/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package m2;

/**
 *
 * @author user
 */
public class Appointments {
    
    public Appointments() {
        String StudentName;
        String counselor;
        String date;
        String time;
        String status;
        

    
    
}
