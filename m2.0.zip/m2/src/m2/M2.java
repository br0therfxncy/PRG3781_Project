/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package m2;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author user
 */
public class M2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        //String url = "jdbc:mysql://localhost:3306/mysql?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String dbUrl = "jdbc:derby:feedbackDB;create=true";
        Connection conn = DriverManager.getConnection(dbUrl);
        // TODO code application logic here
        /*java.awt.EventQueue.invokeLater(() -> {
        new Dashboard().setVisible(true);  
    });
        
        java.awt.EventQueue.invokeLater(() -> {
        new Appointments().setVisible(true);  
    });
        
        /*java.awt.EventQueue.invokeLater(() -> {
        new CounselorManage().setVisible(true);  
    });
        
        java.awt.EventQueue.invokeLater(() -> {
        new Feedback().setVisible(true);  
    });*/
    }
    
}
